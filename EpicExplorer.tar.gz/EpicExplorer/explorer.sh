#!/usr/bin/bash
#source venv/bin/activate
cd /matrix/nginx-proxy/data/EpicExplorer
. venv/bin/activate
export SECRET_KEY=somesecretkey
#export SECRET_KEY=N6gGGK8ZuhaIo3ignRyP
export DB_NAME=explorertestnet
export DB_USER=epicuser
export DB_PASSWORD=epicpass
#export DB_HOST=5.9.155.102
export DB_HOST=127.0.0.1
export DB_PORT=5432
cd epicexplorer/
python3 manage.py import_from_tip http://127.0.0.1:3413/
#python3 manage.py import_from_tip http://127.0.0.1:3413/
