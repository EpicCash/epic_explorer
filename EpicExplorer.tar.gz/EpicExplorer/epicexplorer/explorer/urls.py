from django.urls import path

from .views import BlockList, BlocksByHeight, BlockDetail, Search, Docs, Walletdocs, Minerdocs, Pooldocs, Nodedocs, Newversiondocs
from .charts import block_chart, fee_chart


urlpatterns = [
    path('', BlockList.as_view(), name="block-list"),
    #path('change_paginate', BlockList.change_paginate, name="change_paginate")
    path("chart/block", block_chart, name="block-chart"),
    path("chart/fee", fee_chart, name="fee-chart"),
    path("block/<int:height>", BlocksByHeight.as_view(), name="blocks-by-height"),
    path("block/<str:pk>", BlockDetail.as_view(), name="block-detail"),
    path("search", Search.as_view(), name="search"),
    path("docs/", Docs.as_view(), name="docs"),
    path("docs/wallet", Walletdocs.as_view(), name="wallet-docs"),
    path("docs/miner", Minerdocs.as_view(), name="miner-docs"),
    path("docs/pool", Pooldocs.as_view(), name="pool-docs"),
    path("docs/node", Nodedocs.as_view(), name="node-docs"),
    path("docs/newversion", Newversiondocs.as_view(), name="newversion-docs"),
]
