from django.db.models import Count, Sum, Max, Min
from django.db.models.functions import TruncDay
from django.views.generic import ListView, DetailView, TemplateView
from django.shortcuts import redirect
from django.template import RequestContext
from django.http import HttpResponse

from blockchain.models import Block, Output
from chartit import DataPool, Chart
import requests
#import urllib.parse
import datetime


class BlockList(ListView):
    template_name = "explorer/block_list.html"
    context_object_name = "block_list"

    queryset = Block.objects.order_by("-timestamp")
    paginate_by = 20
    request = 0;



    def get_paginate_by(self,queryset):
        size = self.request.GET.get('size')
        myList = [20,50,100,500,1000]
        if size:
            int_size = int(size)
            if int_size in myList:
                return int_size
            else:
                return 20;
        return 20;

    def get_block_chart(self):
        blockpivotdata = DataPool(
            series=[{
                'options': {
                    'source': Block.objects.raw("select 1 as hash, to_char(timestamp,'MM-dd') as niceday, "
                                                "max(total_difficulty) as total_difficulty, "
                                                "date(DATE_TRUNC('day', timestamp)) as date, count(hash) as num "
                                                "from blockchain_block "
                                                "group by DATE_TRUNC('day', timestamp),niceday order by date")
                },
                'terms': [
                    'niceday',
                    {'Number':'num'},
                    {'Total Difficulty':'total_difficulty'},
                ]
            }]
        )

        blockpivcht = Chart(
            datasource=blockpivotdata,
            series_options=[{
                'options': {
                    'type': 'line',
                    'xAxis': 0,
                    'yAxis': 0,
                    'zIndex': 1,
                    'legendIndex': 1,
                    'color':'#6db0ed',
                },
                'terms': {
                    'niceday': ['Number']
                }}, {
                'options': {
                    'type': 'line',
                    'xAxis': 1,
                    'yAxis': 1,
                    'legendIndex': 0,
                    'color':'#517ba0',
                },
                'terms': {
                    'niceday': ['Total Difficulty']
                }
            }],
            chart_options={
                'title': {
                    'text': 'Blocks and Difficulty'
                },
                'xAxis': [
                    {
                        'title': {
                            'text': 'Date',
                            'style': {
                                'display': 'none'
                            }
                        },
                        'labels': {
                            'enabled': True
                        }
                    },
                    {
                        'title': {
                            'text': 'Date',
                            'style': {
                                'display': 'none'
                            }
                        },
                        'labels': {
                            'enabled': False
                        },
                        'lineColor': 'transperant',
                        'tickLength': 0,
                    }
                ],
                'yAxis': [
                    {
                        'title': {
                            'text': 'Blocks',
                            'style': {
                                'color': '#6db0ed'
                            }
                        },
                        'labels': {
                            'enabled': True
                        },
                    },
                    {
                        'title': {
                            'text': 'Diff',
			    'style': {
                                'color': '#517ba0'
                 	     }
                        },
                        'labels': {
                            'enabled': True
                        }
                    }
                ],
                'legend': {
                    'enabled': False
                },
                'credits': {
                'enabled': False},
            }
        )
        return blockpivcht

    def get_fee_chart(self):
        feepivotdata = DataPool(
            series=[{
                'options': {
                    'source': Block.objects.raw("select 1 as hash, to_char(timestamp,'MM-dd') as niceday, "
                                                "date(DATE_TRUNC('day', timestamp)) as date, sum(fee)/1000000 as fee "
                                                "from blockchain_block t1 join blockchain_kernel t2 "
                                                "on t2.block_id=t1.hash "
                                                "group by DATE_TRUNC('day', timestamp),niceday order by date")
                },
                'terms': [
                    'niceday',
                    {'Fee':'fee'}
                ]
            }]
        )

        feepivcht = Chart(
            datasource=feepivotdata,
            series_options=[{
                'options': {
                    'type': 'line',
                    'stacking': False
                },
                'terms': {
                    'niceday': [
                        'Fee',
                    ]
                }
            }],
            chart_options={
                'title': {
                    'text': 'Transaction Fee Chart'},
                'xAxis': {
                    'title': {
                        'text': 'Date'}},
                'yAxis': {
                    'title': {
                        'text': 'Tx Fee'}},
                'legend': {
                    'enabled': False},
                'credits': {
                    'enabled': False}},
        )
        return feepivcht

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        if Block.objects.exists():
            context["highest_block"] = Block.objects.order_by("height").last()
            context["latest_block"] = Block.objects.order_by("timestamp").last()

            #currentdate = datetime.datetime.now() - datetime.datetime.now(Block.objects.order_by("timestamp").last().timestamp)
            #context["test"] = Block.objects.order_by("timestamp").last().timestamp
            tz_info = Block.objects.order_by("timestamp").last().timestamp.tzinfo
            diff = datetime.datetime.now(tz_info) - Block.objects.order_by("timestamp").last().timestamp
            context["test"] = int(diff.total_seconds())


            #context["total_emission"] = Block.objects.order_by("total_difficulty").last().height * 250
            context["total_emission"] = self.reward_calc(Block.objects.order_by("total_difficulty").last().height)
            context["competing_chains"] = Block.objects \
                                               .filter(height__gte=context["highest_block"].height - 25) \
                                               .values("height") \
                                               .annotate(cnt=Count("height")) \
                                               .aggregate(Max("cnt"))["cnt__max"]
            context["forked_at"] = Block.objects \
                                        .filter(height__gte=context["highest_block"].height - 25) \
                                        .values("height") \
                                        .annotate(cnt=Count("height")) \
                                        .filter(cnt__gt=1) \
                                        .aggregate(Min("height"))["height__min"]

            context['thumb_chart_list'] = [self.get_block_chart(), self.get_fee_chart()]

        return context

    def reward_calc(self, height):
        if height > 12960:
            remain_block = height - 12960
            return (1440 * 200 + 1440 * 180 + 1440 * 160 + 1440 * 140 + 1440 * 120 + 1440 * 100 + 1440 * 80 + 1440 * 60 + 1440 *50 + 25 * remain_block )
        elif height > 11520:
            remain_block = height - 11520
            return (1440 * 200 + 1440 * 180 + 1440 * 160 + 1440 * 140 + 1440 * 120 + 1440 * 100 + 1440 * 80 + 1440 * 60 + remain_block * 50)
        elif height > 10080:
            remain_block = height - 10080
            return (1440 * 200 + 1440 * 180 + 1440 * 160 + 1440 * 140 + 1440 * 120 + 1440 * 100 + 1440 * 80 + remain_block * 60)
        elif height > 8640:
            remain_block = height - 8640
            return (1440 * 200 + 1440 * 180 + 1440 * 160 + 1440 * 140 + 1440 * 120 + 1440 * 100 + remain_block * 80)
        elif height > 7200:
            remain_block = height - 7200
            return (1440 * 200 + 1440 * 180 + 1440 * 160 + 1440 * 140 + 1440 * 120 + remain_block * 100 )
        elif height > 5760:
            remain_block = height - 5760
            return (1440 * 200 + 1440 * 180 + 1440 * 160 + 1440 * 140 + remain_block * 120)
        elif height > 4320:
            remain_block = height - 4320
            return (1440 * 200 + 1440 * 180 + 1440 * 160 + remain_block * 140)
        elif height > 2880:
            remain_block = height - 2880
            return (1440 * 200 + 1440 * 180 + remain_block * 160)
        elif height > 1440:
            remain_block = height - 1440
            return (1440 * 200 + remain_block * 180)
        else:
            return height * 200




class BlockDetail(DetailView):
    model = Block

    template_name = "explorer/block_detail.html"
    context_object_name = "blk"

class Docs(TemplateView):
    template_name = "explorer/docs1.html"

    def get_context_data(self, **kwargs):
        url = "http://88.99.249.119:13423/pool/users"
        r = requests.get(url)
        context = {}
        context["data"] = r.json()
        return context

class Walletdocs(TemplateView):
    template_name = "explorer/wallet_docs.html"

    def get_context_data(self, **kwargs):
        url = "http://88.99.249.119:13423/pool/users"
        r = requests.get(url)
        context = {}
        context["data"] = r.json()
        return context

class Minerdocs(TemplateView):
    template_name = "explorer/miner_docs.html"

class Newversiondocs(TemplateView):
    template_name = "explorer/newversion_docs.html"

class Pooldocs(TemplateView):
    template_name = "explorer/pool_docs.html"

class Nodedocs(TemplateView):
    template_name = "explorer/node_docs.html"

class BlocksByHeight(TemplateView):
    template_name = "explorer/blocks_by_height.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        context["blocks"] = self.blocks
        context["height"] = self.height

        return context

    def get(self, request, height):
        self.blocks = Block.objects.filter(height=height).order_by("-total_difficulty")
        self.height = height

        if len(self.blocks) == 1:
            return redirect("block-detail", pk=self.blocks[0].hash, permanent=False)
        else:
            return super().get(request)


class Search(TemplateView):
    template_name = "explorer/search_results.html"
    results = None
    q_isdigit = False

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        context["q"] = self.q
        context["q_isdigit"] = self.q_isdigit
        context["results"] = self.results

        return context

    def get(self, request):
        self.q = request.GET.get("q", "").strip()

        # search query is valid block height
        if self.q.isdigit():
            self.q_isdigit = True

            if Block.objects.filter(height=self.q).count():
                return redirect("blocks-by-height", height=self.q, permanent=False)

        # require at least 8 characters
        if len(self.q) >= 6:
            self.results = Block.objects.filter(hash__startswith=self.q)

            # if only one result, redirect to found block
            if self.results.count() == 1:
                return redirect("block-detail", pk=self.results[0].hash, permanent=False)

        return super().get(request)
