from decimal import Decimal
from django import template

register = template.Library()


def format_float(f):
    s = "{:,f}".format(f)
    if "." not in s:
        return s

    return s.rstrip("0").rstrip(".")


@register.filter
def nanoepic(nanoepic):
    if nanoepic == 0:
        return epic(0)

    if nanoepic < 1000:
        return "%d Epic" % (nanoepic / 1000000000)

    return microepic(Decimal(nanoepic) / Decimal(1000))


@register.filter
def microepic(microepic):
    if microepic == 0:
        return epic(0)

    if microepic < 1000:
        return "%s Epic" % ((microepic * 1000000) / 1000000000)

    return milliepic(Decimal(microepic) / Decimal(1000))


@register.filter
def milliepic(milliepic):
    if milliepic == 0:
        return epic(0)

    if milliepic < 1000:
        return "%s Epic" % ((milliepic * 1000) / 1000000000)

    return epic(Decimal(milliepic) / Decimal(1000))


@register.filter
def epic(epic):
    return "%s Epic" % format_float(epic)
